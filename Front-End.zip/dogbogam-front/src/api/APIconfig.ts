export const BASE_URL = "https://j11b101.p.ssafy.io/api/";
